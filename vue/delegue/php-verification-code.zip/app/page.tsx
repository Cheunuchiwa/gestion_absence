"use client"

import  from "../verification-code"

export default function SyntheticV0PageForDeployment() {
  return < />
}